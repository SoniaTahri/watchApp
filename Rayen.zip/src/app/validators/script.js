var listOfFriends = ["Damien", "Thomas", "Jean-Claude Dusse"];
listOfFriends.forEach(function (friend) {
    console.log(friend);
});
