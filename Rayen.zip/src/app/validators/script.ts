
let listOfFriends = ["Damien", "Thomas", "Jean-Claude Dusse"];
listOfFriends.forEach((friend: string) => {

    console.log(friend);

});