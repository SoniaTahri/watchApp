export class Montre {
    constructor(
        public id:string,
        public price:number,
        public marque: string,
        public image:string,
        public description: string
    ) {}
}